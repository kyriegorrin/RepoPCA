#!/bin/bash

./script.sh pi.O0 pi.O3 500 1000 500 3
./script.sh pi.O0 popul.O3 500 1000 500 3
